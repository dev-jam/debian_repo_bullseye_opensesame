# -*- coding: utf-8 -*-
"""
pyqode.language_server is an extension of pyqode.core that brings support
for language servers.
"""

__version__ = '0.1.11'
