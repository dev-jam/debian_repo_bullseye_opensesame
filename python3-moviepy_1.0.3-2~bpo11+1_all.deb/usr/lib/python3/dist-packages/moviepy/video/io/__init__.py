"""
Classes and methods for reading, writing and previewing video files.
"""
